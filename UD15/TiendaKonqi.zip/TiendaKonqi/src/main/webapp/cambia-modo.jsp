<%-- 
    Document   : cambia-modo.jsp
    Created on : 14 apr 2025, 18:29:06
    Author     : 1� DAM-T
--%>

<%
    // TODO: Establecemos en la sesi�n el atributo 'modo' con el valor del par�metro 'modo' de la petici�n HTTP recibida
    String nuevoModo = request.getParameter("modo");
    if (nuevoModo != null && !nuevoModo.isEmpty()) {
        session.setAttribute("modo", nuevoModo);
    }
    // Volvemos a index.jsp
    response.sendRedirect("index.jsp");
%>
