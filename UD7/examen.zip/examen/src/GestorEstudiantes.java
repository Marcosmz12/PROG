public class GestorEstudiantes {
    private int[] estudiantes = new int[20];
    private int cantidadEstudiantes;
}
